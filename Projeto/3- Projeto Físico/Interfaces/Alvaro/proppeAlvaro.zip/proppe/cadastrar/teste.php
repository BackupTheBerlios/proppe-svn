<?php
	ob_start();
	require_once('conexao.php');
	$matricula = $_POST['mat'];
	$senha = $_POST['pass'];
	$query= "SELECT * FROM matricula WHERE matricula = '$matricula' AND senha = '$senha'";
	$rs = mysql_query($query) or die ("Imposs�vel realizar consulta no banco de dados. Tente novamente.");
	if(mysql_num_rows($rs) == 0)
    {
		echo "O usu�rio ou a senha est� incorreto.";
    }
    else
	{
		session_start();
		$_SESSION[matricula] = $matricula;
		$_SESSION[senha] = $senha;
		
		header("Location: passo3.php");
	}

?>