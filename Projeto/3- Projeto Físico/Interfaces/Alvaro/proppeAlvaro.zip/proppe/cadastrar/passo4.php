﻿<div class="myBox" id="titulo">
	<h2>Dados Pessoais</h2>
	<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
	<label for="user">Titulação</label>
	<select name="titulacao" class="myInput"> 
		
	</select>
	
	<label for="psw">Grande Área</label>
	<select name="titulacao" class="myInput"> 
		
	</select>
	
	<label for="psw">Área</label>
	<select name="titulacao" class="myInput"> 
		
	</select>
	
	<label for="user">Curso</label>
	<select name="titulacao" class="myInput">
		
	</select>
	
	<div class="continuar_voltar">
		<a href="passo3.php" class="botao" onClick='mudarPasso(3);ajaxGo({url: this.href, elem_return: "conteudo", loading: "Carre<b>gando</b>", timeout: 4}); return false;'>Voltar</a>
		<a href="passo5.php" class="botao" onClick='mudarPasso(5);ajaxGo({url: this.href, elem_return: "conteudo", loading: "Carre<b>gando</b>", timeout: 4}); return false;'>Próximo</a>
	</div>
	
</div>