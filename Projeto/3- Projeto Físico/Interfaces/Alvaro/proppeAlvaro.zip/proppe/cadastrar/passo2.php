﻿<html>
<body>
<div class="myBox" id="lyceum">
	<h2>Dados Lyceum</h2>
	<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
	<form id="teste" method='POST' action="teste.php">
		<label> Matricula:</label>
		<input type="text" class="myInput" name="mat" id="mat"/>
			
		<label> Senha: </label>
		<input type="text"  class="myInput" name="pass" id="pass"/><br /><br />
		
		<div class="continuar_voltar">
			<a href="passo1.php" class="botao" onClick='mudarPasso(1);ajaxGo({url: this.href, elem_return: "conteudo", loading: "Carre<b>gando</b>", timeout: 4}); return false;' >Voltar</a>
			<a href="passo3.php" class="botao" onClick='mudarPasso(3);ajaxGo({url: this.href, elem_return: "conteudo", loading: "Carre<b>gando</b>", timeout: 4}); return false;'>Próximo</a>
		</div>
	</form>
	
</div>
</body>
</html>