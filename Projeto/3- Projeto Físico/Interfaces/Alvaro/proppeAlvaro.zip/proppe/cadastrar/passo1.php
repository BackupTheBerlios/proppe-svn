﻿<html>
<body>
<div class="myBox" id="termos">
	<h2>Termos e condi&ccedil;ões</h2>
	<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
	
	<label id="contrato">
	<textarea name="" cols="90" rows="10">Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
	</textarea>
	</label>
	
	<label for='aceito'>
		<input type="checkbox" name="option1" value="sim">Eu li, entendi e concordo com essas regras e condições.
	</label>
	
	<div class="continuar_voltar">
		<a href="../index.htm">Cancelar</a>
		<a href="passo2.php" onClick='mudarPasso(2);ajaxGo({url: this.href, elem_return: "conteudo", loading: "Carre<b>gando</b>", timeout: 4}); return false;'>Próximo</a>
		
	</div>
</div>

</body>
</html>