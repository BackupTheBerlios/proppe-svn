﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css" />
<link href="../css/cadastrar.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="../javascript/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="../javascript/ajaxGo-1.3.js"></script>
<script type="text/javascript">
	var passoAtual = 1	
	mudarPasso = function(numeroPasso)
	{
		$("#ps"+passoAtual).toggleClass("selecionar")
		$("#ps"+numeroPasso).toggleClass("selecionar")
		passoAtual = numeroPasso
	}
</script>


</head>

<body>
<div id="container">

	<div id="topo">
		<h1><span>Coordenadoria de Pesquisa</span></h1>
		<h3><span>Centro Universitário de AnÃ¡polis UniEvangélica</span></h3>
	</div>
		
	<div id="menuH">
		<ul>
			<li><a href="#">Início</a></li>
			<li><a href="#">ProPPE</a></li>
			<li><a href="#">PBIC</a></li>
			<li><a href="#">Edital</a></li>
			<li><a href="#">Agenda</a></li>
			<li><a href="#">Contato</a></li>
		</ul>
	</div>
		
	<div id="banner">
	</div>
	
	<div id="passo">
		<ul>
			<li id="ps1" class="selecionar">Passo 1</li>
			<li id="ps2">Passo 2</li>
			<li id="ps3">Passo 3</li>
			<li id="ps4">Passo 4</li>
			<li id="ps5">Confirmar</li>
		</ul>
	</div>
	
	
  	<div id="conteudo">
		<?php include("passo1.php");?>
    </div>
	
</div>   

</div>
</body>
</html>