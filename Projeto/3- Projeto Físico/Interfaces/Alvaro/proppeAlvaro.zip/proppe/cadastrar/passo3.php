<?php
	session_start();
	require_once('conexao.php');
	$matricula = $_SESSION['matricula'];
	$senha = $_SESSION['senha'];
	
	$sql = "SELECT * FROM prof WHERE login = '$matricula'";
	$rs = mysql_query($sql);
	$campos = mysql_fetch_array($rs);
	
	unset($_SESSION[matricula]);
	unset($_SESSION[senha]);
	
	session_destroy();
?>

<div class="myBox" id="dPessoa">
	<h2>Dados Pessoais</h2>
	<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
	<form action="">
		<div id="dadosP1">
			<label for="nome">Nome:</label>
			<input type="text" id="nome" class="myInput" name="nome" value="<?php echo $campos["nome"]; ?>" size="40"/>
			
			<label for="sobre">Sobrenome:</label>
			<input type="text" id="sobre" class="myInput" size="40"/>
				   
			<label for="email">E-mail:</label>
			<input type="text" id="email" class="myInput" name="email" size="40"/>
			
			<label for="tel">Telefone:</label>
			<input type="text" id="tel" class="myInput" size="40"/><br/> <br/>

		</div>

		<div id="dadosP2">
			<label for="endereco">Endereço:</label>
			<input type="text" id="endereco" class="myInput" size="40"/>
			
			<label for="cidade">Cidade:</label>
			<input type="text"  id="cidade" class="myInput" size="40"/>
			
			<label for="estado">Estado:</label>
			<input type="text" id="estado" class="myInput" size="40"/>
			
			<label for="dataN">Data de nascimento:</label>
			<input type="text" id="dataN" class="myInput" size="40"/>
			
		</div>
		
		<div class="continuar_voltar">
			<a href="passo2.php" class="botao" onClick='mudarPasso(2);ajaxGo({url: this.href, elem_return: "conteudo", loading: "Carre<b>gando</b>", timeout: 4}); return false;'>Voltar</a>
			<a href="passo4.php" class="botao" onClick='mudarPasso(4);ajaxGo({url: this.href, elem_return: "conteudo", loading: "Carre<b>gando</b>", timeout: 4}); return false;'>Próximo</a>
		</div>
		
	</form>
</div>