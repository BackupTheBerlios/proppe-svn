<?php

include ("conexao.php");
$cnx =connectToDb($dbserver, $dbuser, $dbpass, $dbname);

$cpf = $_GET['cpf'];
$consulta = mysql_query ("select * from pesquisador where cpf ='$cpf'");
if(mysql_num_rows($consulta) > 0) echo "CPF: <b>$cpf</b> j&aacute cadastrado!";

?>