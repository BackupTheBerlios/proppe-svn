function VerificaSenha(nome) {

document.getElementById('msg_senha').innerHTML = "";

senha = document.form.senha.value;
conf_senha = document.form.conf_senha.value;
if (senha != conf_senha)  {
form.senha.focus();
form.senha.value = '';
form.conf_senha.value = '';
document.getElementById('msg_senha').innerHTML = "Senha n�o confere!";
return false;
}

if (document.form.senha.value.length <6)  {
form.senha.focus();
form.senha.value = '';
form.conf_senha.value = '';
document.getElementById('msg_senha').innerHTML = "M�nimo 6 caracteres!";
return false;
}
}