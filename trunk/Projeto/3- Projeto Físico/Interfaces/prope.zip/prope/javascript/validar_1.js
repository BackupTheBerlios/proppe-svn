function validar(form) {

ga = document.form.ga.value;
if (ga == "") {
alert("Faltou o campo Grande �rea!");
form.ga.focus();
return false;
}

area = document.form.area.value;
if (area == "") {
alert("Faltou o campo �rea!");
form.area.focus();
return false;
}
	
estado_esp = document.form.estado_esp.value;
if (estado_esp == "") {
alert("Faltou o campo Estado da Institui��o!");
form.estado_esp.focus();
return false;
}

cidade_esp = document.form.cidade_esp.value;
if (cidade_esp == "") {
alert("Faltou o campo Cidade da Institui��o!");
form.cidade_esp.focus();
return false;
}
				
cod_inst = document.form.cod_inst.value;
if (cod_inst == "") {
alert("Faltou o campo Nome Institui��o!");
form.cod_inst.focus();
return false;
}

titulacaoMaxima = document.form.titulacaoMaxima.value;
if (titulacaoMaxima == "") {
alert("Faltou o campo Titula��o Maxima!");
form.titulacaoMaxima.focus();
return false;
}

senha = document.form.senha.value;
conf_senha = document.form.conf_senha.value;
if (senha != conf_senha)  {
alert("Senha n�o confere!");
form.senha.focus();
form.senha.value = '';
form.conf_senha.value = '';
return false;
}

if (document.form.senha.value.length <6)  {
alert("Senha tem que conter 6 digitos!");
form.senha.focus();
form.senha.value = '';
form.conf_senha.value = '';
return false;
}

nome = document.form.nome.value;
if (nome == "") {
alert("Faltou o campo Nome!");
form.nome.focus();
return false;
}

rg = document.form.rg.value;
if (rg == "") {
alert("Faltou o campo RG!");
form.rg.focus();
return false;
}

orgaoEmissor = document.form.orgaoEmissor.value;
if (orgaoEmissor == "") {
alert("Faltou o campo Org�o Emissor!");
form.orgaoEmissor.focus();
return false;
}

cpf = document.form.cpf.value;
if (cpf == "") {
alert("Faltou o campo CPF!");
form.cpf.focus();
return false;
}

endereco = document.form.endereco.value;
if (endereco == "") {
alert("Faltou o campo Endereco!");
form.endereco.focus();
return false;
}

estado = document.form.estado.value;
if (estado == "") {
alert("Faltou o campo Estado!");
form.estado.focus();
return false;
}

cidade = document.form.cidade.value;
if (cidade == "") {
alert("Faltou o campo Cidade!");
form.cidade.focus();
return false;
}

cep = document.form.cep.value;
if (cep == "") {
alert("Faltou o campo CEP!");
form.cep.focus();
return false;
}

fone = document.form.fone.value;
if (fone == "") {
alert("Faltou o campo Telefone!");
form.fone.focus();
return false;
}

banco = document.form.banco.value;
if (banco == "") {
alert("Faltou o campo Banco!");
form.banco.focus();
return false;
}


agencia = document.form.agencia.value;
if (agencia == "") {
alert("Faltou o campo Agencia!");
form.agencia.focus();
return false;
}

conta = document.form.conta.value;
if (conta == "") {
alert("Faltou o campo Conta!");
form.conta.focus();
return false;
	}
alert('Clique em Ok para finalizar o cadastro!');
return true;
} 