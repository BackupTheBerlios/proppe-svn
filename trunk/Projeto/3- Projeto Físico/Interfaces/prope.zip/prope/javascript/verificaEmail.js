function VerificaEmail(nome) {
document.getElementById('msg_email').innerHTML = "";
parte1 = document.form.email.value.indexOf("@");
parte2 = document.form.email.value.indexOf(".");
parte3 = document.form.email.value.length;
if (!(parte1 >= 3 && parte2 >= 6 && parte3 >= 9)) {
document.form.email.focus();
document.getElementById('msg_email').innerHTML = "E-mail invalido!";
form.email.value = '';
return false;
}
}