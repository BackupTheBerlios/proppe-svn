function Mascara (formato, keypress, objeto){
campo = eval (objeto);

	// cep
	if (formato=='cep'){
	separador = '-';
	conjunto1 = 5;
	if (campo.value.length == conjunto1){
	campo.value = campo.value + separador;}
	}

	// cpf
	if (formato=='cpf'){
	separador1 = '.';
	separador2 = '-';
	conjunto1 = 3;
	conjunto2 = 7;
	conjunto3 = 11;
	if (campo.value.length == conjunto1)
	  {
	  campo.value = campo.value + separador1;
	  }
	if (campo.value.length == conjunto2)
	  {
	  campo.value = campo.value + separador1;
	  }
	if (campo.value.length == conjunto3)
	  {
	  campo.value = campo.value + separador2;
	  }
	}

	// telefone
	if (formato=='fone'){
	separador1 = '(';
	separador2 = ')';
	separador3 = '-';
	conjunto1 = 0;
	conjunto2 = 3;
	conjunto3 = 8;
	if (campo.value.length == conjunto1){
	campo.value = campo.value + separador1;
	}
	if (campo.value.length == conjunto2){
	campo.value = campo.value + separador2;
	}
	if (campo.value.length == conjunto3){
	campo.value = campo.value + separador3;
	}
	}

}