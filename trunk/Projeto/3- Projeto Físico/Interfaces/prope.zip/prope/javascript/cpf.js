
var msgCPF = 'no';
/*
Valida��o do CPF atrav�s do m�dulo 11
*/
//fun��o que verifica a veracidade do CPF
function VerificaCPF(nome) {
document.getElementById('cpf_erro').innerHTML = "";
var CPF = getValue(nome); // Recebe o valor digitado no campo
// Verifica se o campo � nulo
if (CPF == '') {
return false;
}
CPF = Limp(CPF);
total = CPF.length;
for(t=0; t < 10; t++){
cont = 0;
for(a=0; a < total; a++){
 if(CPF.substring(a,a+1)==(t+'')){
  cont++;
  if(cont == 11){ setValue(nome, "");
  document.getElementById('cpf_erro').innerHTML = "CPF Inexistente!";
 return false;}
 }
}
}
// Aqui come�a a checagem do CPF
var POSICAO, I, SOMA, DV, DV_INFORMADO;
var DIGITO = new Array(10);
DV_INFORMADO = CPF.substr(9, 2); // Retira os dois �ltimos d�gitos do n�mero informado
// Desemembra o n�mero do CPF na array DIGITO
for (I=0; I<=8; I++) {
DIGITO[I] = CPF.substr( I, 1);
}
// Calcula o valor do 10� d�gito da verifica��o
POSICAO = 10;
SOMA = 0;
for (I=0; I<=8; I++) {
SOMA = SOMA + DIGITO[I] * POSICAO;
POSICAO = POSICAO - 1;
}
DIGITO[9] = SOMA % 11;
if (DIGITO[9] < 2) { DIGITO[9] = 0; }
else{ DIGITO[9] = 11 - DIGITO[9]; }
// Calcula o valor do 11� d�gito da verifica��o
POSICAO = 11;
SOMA = 0;
for (I=0; I<=9; I++) {
SOMA = SOMA + DIGITO[I] * POSICAO;
POSICAO = POSICAO - 1;
}
DIGITO[10] = SOMA % 11;
if (DIGITO[10] < 2) { DIGITO[10] = 0; }
else { DIGITO[10] = 11 - DIGITO[10]; }
// Verifica se os valores dos d�gitos verificadores conferem
DV = DIGITO[9] * 10 + DIGITO[10];
if (DV != DV_INFORMADO) {
if(msgCPF == 'no')
 document.getElementById('cpf_erro').innerHTML = "CPF Inexistente!";
 setValue(nome, "");
return false;

}
return true;
}

function FormataCPF(nome){
CPF = getValue(nome);
CPF = Limp(CPF);
if(CPF.length == 11){
value = Mascara(CPF, '999.999.999-99');
setValue(nome, value);
msgCPF = 'no';
} else {
if(CPF.length > 0){
 document.getElementById('cpf_erro').innerHTML = "CPF Incompleto!";
 setValue(nome, "");
 msgCPF = 'yes';
} else msgCPF = 'no';
}
}
//fun��o para Limpar e deixar somente os n�meros.
function Limp(c){
qtd = c.length;
var v = '';
for (i=0; i < qtd; i++)
for(t=0; t < 10; t++){
 if(c.substring(i,i+1) == t && c.substring(i,i+1) != " ") v += c.substring(i,i+1);}
return(v);
}

/*
Fun��es para pegar o valor, e atribuir um valor ao campo q �s chama.
*/
function getValue(nome){
var obj = eval("document.forms[0]."+nome+".value");
return obj;
}
function setValue(nome, valor){
obj = eval("document.forms[0]."+nome);
obj.value = valor;
}