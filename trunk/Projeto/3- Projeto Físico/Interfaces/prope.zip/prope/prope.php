<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <title>UniEVANG�LICA - Centro Universit�rio de An�polis - Um novo tempo sempre</title>
        <LINK REL="SHORTCUT ICON" HREF="http://www.unievangelica.edu.br/imagens5/favicon.ico" >
        <link href="/includes/estilo5.css" rel="stylesheet" type="text/css" >
        <link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="http://www.unievangelica.edu.br/rss.php" >
        <script type="text/javascript">
        function carregaPagina(form){
        //	alert('ssss'+form.value);
            location.href=form.value;
        }
        function janela(url){
            window.open('http://www.unievangelica.edu.br/'+url,'imagem','height = 600, width = 500, resizable, scrollbars=1');
        }
        /* PARA COMPATIBILIDADE COM VERS�O ANTERIOR */
        function mostraevento(url){
            window.open('http://webmail.unievangelica.edu.br/~unifotos/'+url,'imagem','height = 600, width = 800, resizable');
        }
        </script>
    
        <style type="text/css">
			@import url("css/estilo.css");
        </style>
        <!-- Fim do Tabs com AJAX -->
        <script src="/SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
        <link href="/SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css">
	

<?php
	
include ("conexao.php");
$cnx =connectToDb($dbserver, $dbuser, $dbpass, $dbname);

// select grandeArea
@$query_grandeArea = "SELECT * FROM grande_area ORDER BY nome"; 
@$query_grandeArea = mysql_query($query_grandeArea);       
@$row_grandeArea = mysql_num_rows($query_grandeArea);

// select area
@$ga = $_POST["ga"];
@$query_area = "SELECT * FROM  area WHERE cod_ga = '$ga' ORDER BY nome"; 
@$query_area = mysql_query($query_area);       
@$row_area = mysql_num_rows($query_area); 

// select subArea 
@$a = $_POST["area"];
@$query_subArea = "SELECT * FROM  sub_area WHERE cod_ga = '$ga' and cod_a = '$a' ORDER BY nome"; 
@$query_subArea = mysql_query($query_subArea);       
@$row_subArea = mysql_num_rows($query_subArea); 

// select especialidade  
@$sa = $_POST["sub_area"];
@$query_especialidade = "SELECT * FROM  especialidade WHERE cod_ga = '$ga' and cod_a = '$a' and cod_sa = '$sa' ORDER BY nome"; 
@$query_especialidade = mysql_query($query_especialidade);       
@$row_especialidade = mysql_num_rows($query_especialidade); 

// select estado 
@$query_estado = "SELECT * FROM  estado ORDER BY uf"; 
@$query_estado = mysql_query($query_estado);       
@$row_estado = mysql_num_rows($query_estado); 

// select cidadeInstituicao
@$estado_esp=$_POST["estado_esp"];
@$query_cidadeInstituicao = "SELECT distinct instituicao.cidade as cidade, instituicao.uf as uf, cidades.nome as nome FROM  instituicao, cidades where instituicao.uf = '$estado_esp' and instituicao.cidade = cidades.nome ORDER BY cidades.nome"; 
@$query_cidadeInstituicao = mysql_query($query_cidadeInstituicao);       
@$row_cidadeInstituicao = mysql_num_rows($query_cidadeInstituicao); 

// select instituicao 
@$cidade_esp=$_POST["cidade_esp"];
@$query_instituicao = "SELECT * FROM  instituicao where uf = '$estado_esp' and cidade = '$cidade_esp' ORDER BY nome"; 
@$query_instituicao = mysql_query($query_instituicao);       
@$row_instituicao = mysql_num_rows($query_instituicao); 

// select cidade 
@$estado_add=$_POST["estado"];
@$query_cidade = "SELECT * FROM  cidades where uf = '$estado_add' ORDER BY uf"; 
@$query_cidade = mysql_query($query_cidade);       
@$row_cidade = mysql_num_rows($query_cidade); 

?>  

<script type="text/javascript" src="javascript/mascara.js"></script>
<script language="JavaScript" type="text/javascript">
<!--
function Submet(){
with (document.form) {
method = "POST";
action="prope.php";
submit();
}
return true;
}
-->
</script>

<?php if($row_grandeArea !='' and $row_subArea =='') { ?> 

<script language="JavaScript" type="text/javascript" src="javascript/validar_1.js" charset='iso-8859-1'></script>

<?php } else if($row_subArea !='' and $row_especialidade =='') { ?> 

<script language="JavaScript" type="text/javascript" src="javascript/validar_2.js" charset='iso-8859-1'></script>

<?php } if($row_especialidade !='' and $row_subArea !='') { ?>

<script language="JavaScript" type="text/javascript" src="javascript/validar_3.js" charset='iso-8859-1'></script>

<?php } ?>

<script type="text/javascript" src="javascript/verificaEmail.js" charset='iso-8859-1'></script>
<script type="text/javascript" src="javascript/verificaSenha.js" charset='iso-8859-1'></script>
<script type="text/javascript" src="javascript/cpf.js" charset='iso-8859-1'></script>
<script language="javascript" src="javascript/ajax.js"></script>
<script language="javascript">
<!--
function verificaDuplicidade(valor){ 
  url = "pesquisacpf.php?cpf="+valor;
  div = "pesquisacpf";
 
  ajax(url,div);
}
-->
</script>
</head>
<body class="fundo_extra">

<div  id="centralizar"  align="center">
	<div id="geral">
		<?
		require_once(dirname(dirname(dirname(__FILE__))).'/barratopo/barratopo2.php');
		?>
		<div id="conteudo" class="v5_borda_conteudo">
		<!--BlocoPagina-->
        
<table width="95%" border="0" align="center" bgcolor="#FFFFFF" class="texto">
  <form name="form" id="form" method="POST" action="postPrope.php" onsubmit="return validar(this);">
  <tr>
    <td width="15" rowspan="19"></td>
    <td height="22"></td>
    <td width="15" rowspan="19"></td>
  </tr>
  <tr>
    <td height="25" valign="bottom" class="degrade" align="center">Dados da Institui&ccedil;&atilde;o e &Aacute;rea de Atua&ccedil;&atilde;o:</td>
  </tr>
  <tr>
    <td class="v5_borda_conteudo"><table width="95%" border="0" align="center" bgcolor="#FFFFFF" class="texto">
      <tr>
        <td height="22"><div align="left">Escolha a Grande &Aacute;rea: </div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">
          <select name="ga" class="texto" onChange="return Submet(this);">
            <option>Selecione a Grande Area</option>
            <?php for($i_grandeArea=0; $i_grandeArea<$row_grandeArea; $i_grandeArea++) { ?>
            <option <?php if (mysql_result($query_grandeArea, $i_grandeArea, "cod_ga")== $_POST["ga"]) { echo 'selected'; } ?> value="<?php echo mysql_result($query_grandeArea, $i_grandeArea, "cod_ga"); ?>"> <?php echo mysql_result($query_grandeArea, $i_grandeArea, "nome"); ?></option>
            <?php } ?>
          </select>
        </div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">Selecione a &Aacute;rea: </div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">
          <select name="area" class="texto" onChange="Submet(this);">
            <option>Selecione a Area</option>
            <?php for($i_area=0; $i_area<$row_area; $i_area++) { ?>
            <option <?php if (mysql_result($query_area, $i_area, "cod_a")== $_POST["area"]) { echo 'selected'; } ?> value="<?php echo mysql_result($query_area, $i_area, "cod_a"); ?>"> <?php echo mysql_result($query_area, $i_area, "nome"); ?></option>
            <?php }  ?>
          </select>
        </div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">Selecione a Sub-&Aacute;rea: </div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">
          <select name="sub_area" class="texto" onChange="Submet(this);">
            <option value="">Selecione a Sub-Area</option>
            <?php for($i_subArea=0; $i_subArea<$row_subArea; $i_subArea++) { ?>
            <option <?php if (mysql_result($query_subArea, $i_subArea, "cod_sa")== $_POST["sub_area"]) { echo 'selected'; } ?> value="<?php echo mysql_result($query_subArea, $i_subArea, "cod_sa"); ?>"> <?php echo mysql_result($query_subArea, $i_subArea, "nome"); ?></option>
            <?php } ?>
          </select>
        </div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">Selecione a Especialidade: </div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">
          <select name="especialidade" class="texto">
            <option value="">Selecione a Especialidade</option>
            <?php for($i_especialidade=0; $i_especialidade<$row_especialidade; $i_especialidade++) { ?>
            <option <?php if (mysql_result($query_especialidade, $i_especialidade, "cod_e")== $_POST["especialidade"]) { echo 'selected'; } ?> value="<?php echo mysql_result($query_especialidade, $i_especialidade, "cod_e"); ?>"> <?php echo mysql_result($query_especialidade, $i_especialidade, "nome"); ?></option>
            <?php }  ?>
          </select>
        </div></td>
      </tr>
      <tr>
        <td height="25" valign="bottom" class="texto_titulo"><div align="left">Institui&ccedil;&atilde;o de Origem:</div></td>
      </tr>
      <tr>
        <td height="22"> <div align="left">Estado da Institui&ccedil;&atilde;o:</div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">
          <select name="estado_esp" class="texto" onChange="Submet(this);">
            <option>Selecione o Estado</option>
            <?php for($i_estado=0; $i_estado<$row_estado; $i_estado++) { ?>
            <option <?php if (mysql_result($query_estado, $i_estado, "uf")== $_POST["estado_esp"]) { echo 'selected'; } ?> value="<?php echo mysql_result($query_estado, $i_estado, "uf"); ?>"> <?php echo mysql_result($query_estado, $i_estado, "nome"); ?></option>
            <?php }  ?>
          </select>
        </div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">Cidade da Institui&ccedil;&atilde;o:</div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">
          <select name="cidade_esp" class="texto" onChange="Submet(this);">
            <option>Selecione a Cidade</option>
            <?php for($i_cidadeInstituicao=0; $i_cidadeInstituicao<$row_cidadeInstituicao; $i_cidadeInstituicao++) { ?>
            <option <?php if (mysql_result($query_cidadeInstituicao, $i_cidadeInstituicao, "nome")== $_POST["cidade_esp"]) { echo 'selected'; } ?> value="<?php echo mysql_result($query_cidadeInstituicao, $i_cidadeInstituicao, "nome"); ?>"> <?php echo mysql_result($query_cidadeInstituicao, $i_cidadeInstituicao, "nome"); ?></option>
            <?php }  ?>
          </select>
        </div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">Nome da  Institui&ccedil;&atilde;o:</div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">
          <select name="cod_inst" class="texto">
            <option>Selecione a Institui&ccedil;&atilde;o</option>
            <?php for($i_instituicao=0; $i_instituicao<$row_instituicao; $i_instituicao++) { ?>
            <option <?php if (mysql_result($query_instituicao, $i_instituicao, "cod_instituicao")== $_POST["cod_inst"]) { echo 'selected'; } ?> value="<?php echo mysql_result($query_instituicao, $i_instituicao, "cod_instituicao"); ?>"> <?php echo mysql_result($query_instituicao, $i_instituicao, "nome"); ?></option>
            <?php }  ?>
          </select>
        </div></td>
      </tr>
      <!--<tr>
      <td height="22"> <a href="#" class="texto" onclick="window.open('add.php', 'Pagina', 'STATUS=NO, TOOLBAR=NO, LOCATION=NO, DIRECTORIES=NO, RESISABLE=NO, SCROLLBARS=no, TOP=10, LEFT=10, WIDTH=290, HEIGHT=205');"><img src="imagens/seta.jpg" width="12" height="20" border="0" />  Caso n&atilde;o tenha a Institui&ccedil;&atilde;o clique aqui para adicionar! </a> </td>
    </tr>-->
      <tr>
        <td height="25" valign="bottom" class="texto_titulo"><div align="left">Senha de Acesso:</div></td>
      </tr>
      <tr>
        <td height="30" valign="bottom"><div align="left">
          <table width="100%" border="0" cellpadding="0" cellspacing="0" class="texto">
                <tr>
                  <td width="25%" height="22">Senha:</td>
                  <td width="75%" height="22"><input name="senha" type="password" class="input" id="senha" value="<?php echo $_POST["senha"]; ?>" size="8" maxlength="6" />
                      <span id="msg_senha" class="texto_laranja" style="padding-left:05pt"></span></td>
                </tr>
                <tr>
                  <td height="22">Confirma Senha:</td>
                  <td height="22" class="texto"><input name="conf_senha" type="password" class="input" id="conf_senha" value="<?php echo $_POST["conf_senha"]; ?>" size="8" maxlength="6" onChange="VerificaSenha(this.name);" /></td>
                </tr>
                  </table>
        </div></td>
      </tr>
      <tr>
        <td height="25" valign="bottom" class="texto_titulo"><div align="left">Dados Pessoais:</div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">Titula&ccedil;&atilde;o M&aacute;xima: </div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">
          <select name="titulacaoMaxima" class="texto" id="titulacaoMaxima">
            <option>Titula&ccedil;&atilde;o M&aacute;xima</option>
            <option <?php if ($_POST["titulacaoMaxima"]=='1') { echo 'selected'; } ?> value="1">Mestre</option>
            <option <?php if ($_POST["titulacaoMaxima"]=='2') { echo 'selected'; } ?> value="2">Doutor</option>
            <option <?php if ($_POST["titulacaoMaxima"]=='3') { echo 'selected'; } ?> value="3">P&oacute;s-Doutor</option>
          </select>
        </div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">Nome:</div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">
          <input name="nome" type="text" class="input" id="nome" value="<?php echo $_POST["nome"]; ?>" size="60" maxlength="80" />
        </div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">
          <table width="100%" border="0" cellpadding="0" cellspacing="0" class="texto">
                <tr>
                  <td width="38%" height="22">RG/&Oacute;rg&atilde;o Emisor:</td>
                  <td width="62%" height="22">&nbsp;</td>
                </tr>
                <tr>
                  <td height="22" class="texto"><input name="rg" type="text" class="input" id="rg" value="<?php echo $_POST["rg"]; ?>" size="11" maxlength="20" />
                    -
                    <input name="orgaoEmissor" type="text" class="input" id="orgaoEmissor" value="<?php echo $_POST["orgaoEmissor"]; ?>" size="8" maxlength="10" /></td>
                  <td height="22" class="texto">&nbsp;</td>
                </tr>
                <tr>
                  <td height="22" class="texto">CPF:</td>
                  <td height="22" class="texto">&nbsp;</td>
                </tr>
                <tr>
                  <td height="22" colspan="2" class="texto"><input name="cpf" type="text" class="input" id="cpf"  onkeypress="Mascara('cpf', event, 'document.form.cpf');" value="<?php echo $_POST["cpf"]; ?>" size="16" maxlength="14"; onBlur="verificaDuplicidade(value); VerificaCPF(this.name);" />
                      <span id="pesquisacpf" style="padding-left:05pt"></span><span id="cpf_erro" ></span> </td>
                </tr>
                  </table>
        </div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">PIS/PASEP (ou Inscri&ccedil;&atilde;o na Previd&ecirc;ncia):</div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">
          <input name="pisPasep" type="text" class="input" id="pisPasep" value="<?php echo $_POST["pisPasep"]; ?>" size="20" maxlength="30" />
        </div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">E-mail:</div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">
          <input name="email" type="text" class="input" id="email" value="<?php echo $_POST["email"]; ?>" size="60" maxlength="40"  onChange="VerificaEmail(this.name);">
          <span id="msg_email" style="padding-left:05pt"></span></div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">Endere&ccedil;o:</div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">
          <input name="endereco" type="text" class="input" id="endereco" value="<?php echo $_POST["endereco"]; ?>" size="60" maxlength="100" />
        </div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">Estado:</div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">
          <select name="estado" class="texto" onChange="Submet(this);">
            <option>Selecione o Estado</option>
            <?php for($i_estado=0; $i_estado<$row_estado; $i_estado++) { ?>
            <option <?php if (mysql_result($query_estado, $i_estado, "uf")== $_POST["estado"]) { echo 'selected'; } ?> value="<?php echo mysql_result($query_estado, $i_estado, "uf"); ?>"> <?php echo mysql_result($query_estado, $i_estado, "nome"); ?></option>
            <?php }  ?>
          </select>
        </div>        </tr>
      <tr>
        <td height="22"><div align="left">Cidade:</div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">
          <select name="cidade" class="texto">
            <option>Selecione a Cidade</option>
            <?php for($i_cidade=0; $i_cidade<$row_cidade; $i_cidade++) { ?>
            <option <?php if (mysql_result($query_cidade, $i_cidade, "nome")== $_POST["cidade"]) { echo 'selected'; } ?> value="<?php echo mysql_result($query_cidade, $i_cidade, "nome"); ?>"> <?php echo mysql_result($query_cidade, $i_cidade, "nome"); ?></option>
            <?php } ?>
          </select>
        </div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">
          <table width="100%" border="0" cellpadding="0" cellspacing="0" class="texto">
                <tr>
                  <td width="25%" height="22">CEP:</td>
                  <td width="75%" height="22">DDD/Telefone:</td>
                </tr>
                <tr>
                  <td height="22" class="texto"><input name="cep" type="text" class="input" id="cep"  onkeypress="Mascara('cep', window.event.keyCode, 'document.form.cep');" value="<?php echo $_POST["cep"]; ?>" size="11" maxlength="9"; /></td>
                  <td height="22" class="texto"><input name="fone" type="text" class="input" id="fone" value="<?php echo $_POST["fone"]; ?>" size="15" maxlength="13"  onkeypress="Mascara('fone',event , 'document.form.fone');"; /></td>
                </tr>
                  </table>
        </div></td>
      </tr>
      <tr>
        <td height="25" valign="bottom" class="texto_titulo"><div align="left">Dados Banc&aacute;rios:</div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">
          <table width="100%" border="0" cellpadding="0" cellspacing="0" class="texto">
                <tr>
                  <td width="25%" height="22">Banco:</td>
                  <td width="24%" height="22">Ag&ecirc;ncia:</td>
                  <td width="51%" height="22">Conta:</td>
                </tr>
                <tr>
                  <td height="22" class="texto"><input name="banco" type="text" class="input" id="banco" value="<?php echo $_POST["banco"]; ?>" size="12" maxlength="20" /></td>
                  <td height="22" class="texto"><input name="agencia" type="text" class="input" id="agencia" value="<?php echo $_POST["agencia"]; ?>" size="12" maxlength="10" /></td>
                  <td height="22" class="texto"><input name="conta" type="text" class="input" id="conta" value="<?php echo $_POST["conta"]; ?>" size="12" maxlength="10" /></td>
                </tr>
                  </table>
        </div></td>
      </tr>
      <tr>
        <td height="6"><div align="left"></div></td>
      </tr>
      <tr>
        <td height="22"><div align="left">
          <input name="enviar" type="image" src="imagens/enviar.jpg" border="0" />
        </div></td>
      </tr>
    </table></td>
  </tr>
  
    <!--<tr>
      <td height="22"> <a href="#" class="texto" onclick="window.open('add.php', 'Pagina', 'STATUS=NO, TOOLBAR=NO, LOCATION=NO, DIRECTORIES=NO, RESISABLE=NO, SCROLLBARS=no, TOP=10, LEFT=10, WIDTH=290, HEIGHT=205');"><img src="imagens/seta.jpg" width="12" height="20" border="0" />  Caso n�o tenha a Institui��o clique aqui para adicionar! </a> </td>
    </tr>-->
    
  <tr>
    <td height="22" class="texto"></td>
  </tr>
</form></table>
 
<!--FimBlocoPagina-->
        <div id="v5_select"></div>
		<div id="banner_topo"></div>
			<div id="rodape" align="center" class="v5_mui_pequeno"> 
				� UniEVANG�LICA. Todos os direitos reservados. 
				<br>Av. Universit�ria Km. 3,5 - Cidade Universit�ria - An�polis - GO CEP: 75070-290 - Fone: (62) 3310-6600
			</div>
  		</div>
	</div>
</div>   
</body>
</html>