<?php

if ($_POST['ga'] and $_POST['area'] and $_POST['cpf'] and $_POST['senha'] and $_POST['nome']) {

include ("conexao.php");
$cnx =connectToDb($dbserver, $dbuser, $dbpass, $dbname);

$ga_add = $_POST['ga'];
$a_add = $_POST['area'];
$sa_add = $_POST['sub_area'];
$e_add = $_POST['especialidade'];
$inst_add = $_POST['cod_inst'];
$nome_add = $_POST['nome'];
$rg_add = $_POST['rg'];
$orgaoEmissor_add = $_POST['orgaoEmissor'];
$cpf_add = $_POST['cpf'];
$pisPasep_add = $_POST['pisPasep'];
$email_add = $_POST['email'];
$endereco_add = $_POST['endereco'];
$cidade_add = $_POST['cidade'];
$estado_add = $_POST['estado'];
$cep_add = $_POST['cep'];
$titulacaoMaxima_add = $_POST['titulacaoMaxima'];
$fone_add = $_POST['fone'];
$senha_add = md5($_POST['senha']);
$banco_add = $_POST['banco'];
$conta_add = $_POST['conta'];
$agencia = $_POST['agencia'];

if ($e_add > 0 and $sa_add > 0 )
{
		
		$result = mysql_query ("INSERT INTO pesquisador(cod_ga,cod_a,cod_sa,cod_e,cod_instituicao,nome,rg,orgaoEmissor,cpf,pisPasep,email,endereco,
		cidade,uf,cep,fone,senha,banco,conta,titulacaoMaxima,agencia)
						VALUES('$ga_add','$a_add','$sa_add','$e_add','$inst_add','$nome_add','$rg_add','$orgaoEmissor_add','$cpf_add','$pisPasep_add','$email_add','$endereco_add',
						'$cidade_add','$estado_add','$cep_add','$fone_add','$senha_add','$banco_add','$conta_add','$titulacaoMaxima_add','$agencia')");

}

if ($e_add=='' and $sa_add > 0 )
{
		
		$result = mysql_query ("INSERT INTO pesquisador(cod_ga,cod_a,cod_sa,cod_instituicao,nome,rg,orgaoEmissor,cpf,pisPasep,email,endereco,
		cidade,uf,cep,fone,senha,banco,conta,titulacaoMaxima,agencia)
						VALUES('$ga_add','$a_add','$sa_add','$inst_add','$nome_add','$rg_add','$orgaoEmissor_add','$cpf_add','$pisPasep_add','$email_add','$endereco_add',
						'$cidade_add','$estado_add','$cep_add','$fone_add','$senha_add','$banco_add','$conta_add','$titulacaoMaxima_add','$agencia')");

}

if ($e_add=='' and $sa_add=='')
{
		$result = mysql_query ("INSERT INTO pesquisador(cod_ga,cod_a,cod_instituicao,nome,rg,orgaoEmissor,cpf,pisPasep,email,endereco,
		cidade,uf,cep,fone,senha,banco,conta,titulacaoMaxima,agencia)
						VALUES('$ga_add','$a_add','$inst_add','$nome_add','$rg_add','$orgaoEmissor_add','$cpf_add','$pisPasep_add','$email_add','$endereco_add',
						'$cidade_add','$estado_add','$cep_add','$fone_add','$senha_add','$banco_add','$conta_add','$titulacaoMaxima_add','$agencia')");

}

echo "<META HTTP-EQUIV=REFRESH CONTENT=0;url='prope.php'>";

}

else {

echo '<META HTTP-EQUIV=REFRESH CONTENT=0;url="prope.php">';

}
?>
