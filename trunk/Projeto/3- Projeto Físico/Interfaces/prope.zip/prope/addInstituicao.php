<meta http-equiv=Content-Type content="text/html; charset=utf-8">

<style type="text/css">
<!--
@import url("css/estilo.css");
-->
</style>

<script language="JavaScript" type="text/javascript">
<!--
function Submet(){
with (document.form) {
method = "POST";
action="addInstituicao.php";
submit();
}
return true;
}
-->
</script>

<form name="form" action="addInstituicao.php" method="post">
<table width="205" border="0" align="center" cellpadding="0" cellspacing="0">
<tr>
  <td height="15" class="texto_titulo">&nbsp;</td>
</tr>
<tr>
  <td height="22" class="texto_titulo">Adicionar Instituição: </td>
</tr>
<tr>
<td height="22" class="texto">Estado da Instituição:</td>
    </tr>
  <?php 
  include "conexao.php";
  $cnx =connectToDb($dbserver, $dbuser, $dbpass, $dbname);

  @$sql_estado = "SELECT * FROM  estado ORDER BY nome"; 
  @$sql_estado = mysql_query($sql_estado);       
  @$row_estado = mysql_num_rows($sql_estado); 
  ?>  
    <tr>
      <td width="494" height="22" class="texto"><select name="estado_add" class="texto" onChange="return Submet(this);">
                  <option>Selecione o Estado</option>
                  <?php for($i_estado=0; $i_estado<$row_estado; $i_estado++) { ?>
                  <option <?php if (mysql_result($sql_estado, $i_estado, "uf")==$estado_add=$_POST["estado_add"]) { echo 'selected'; } ?> value="<?php echo mysql_result($sql_estado, $i_estado, "uf"); ?>"> 
                  <?php echo mysql_result($sql_estado, $i_estado, "nome"); ?></option>
                  <?php }  ?>
    </select>    </tr>
  <tr>
    <td height="22" class="texto">Cidade da Instituição:</td>
    </tr>
  <tr>
    <?php 
  @$estado_add=$_POST["estado_add"];
  @$sql_cidadeInstituicao = "SELECT * FROM  cidades where uf = '$estado_add' ORDER BY nome"; 
  @$sql_cidadeInstituicao = mysql_query($sql_cidadeInstituicao);       
  @$row_cidadeInstituicao = mysql_num_rows($sql_cidadeInstituicao); 
  ?>  
    <td height="22" class="texto"><select name="cidade_add" class="texto">
                  <option>Selecione a Cidade</option>
                  <?php for($i_cidadeInstituicao=0; $i_cidadeInstituicao<$row_cidadeInstituicao; $i_cidadeInstituicao++) { ?>
                  <option <?php if (mysql_result($sql_cidadeInstituicao, $i_cidadeInstituicao, "nome")==$cidade_add=$_POST["cidade_add"]) { echo 'selected'; } ?> value="<?php echo mysql_result($sql_cidadeInstituicao, $i_cidadeInstituicao, "nome"); ?>"> 
                  <?php echo mysql_result($sql_cidadeInstituicao, $i_cidadeInstituicao, "nome"); ?></option>
                  <?php } ?>
      </select></td>
    </tr>
  <tr>
    <td height="22" class="texto">Nome da Institui&ccedil;&atilde;o:</td>
  </tr>
  <tr>
    <td height="22" class="texto_azul"><input name="nova_inst" type="text" class="input" id="nova_inst" value="<?php echo $nova_inst=$_POST['nova_inst']; ?>" size="40" /></td>
  </tr>
  <tr>
    <td height="32" class="texto_azul"><input name="Submit" type="image" value="Enviar" src="imagens/enviar.jpg" hspace="0" vspace="0" border="0" /></td>
  </tr>
  </table>
</form>