<?php
	//$conexao = mysql_connect("localhost", "root", "") or die('asasas');
	//$banco = mysql_select_db("prope", $conexao);
	$dbserver="localhost";
	$dbuser="prope";
	$dbpass="123";
	$dbname="prope";
	function connectToDb($server, $user, $pass, $database) {
		$s=mysql_connect($server, $user, $pass);
		$d=mysql_select_db($database, $s);
		if(!$s || !$d) {
			return false;
			} else {
				return true;
				}
}
?>